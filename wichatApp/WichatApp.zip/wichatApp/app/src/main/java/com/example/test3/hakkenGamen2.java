package com.example.test3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class hakkenGamen2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hakken_gamen2);
    }
}