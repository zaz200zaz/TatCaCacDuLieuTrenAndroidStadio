package com.example.test3;

import com.journeyapps.barcodescanner.CaptureActivity;

public class Capture extends CaptureActivity {
}
